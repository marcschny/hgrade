{-# LANGUAGE OverloadedStrings #-}

-- Stored in this module are functions, who communicate with the 
--fs through reading or writing files and folders
-- Also certain functions who directly corresponds with that setting are stored in this module

-- !!Functions who just need to read in a directory or 
--   something simple as that are not exported to this module !!

module DirHgrade where

--For interacting with the fs we need certain functions from the System.Directory module
import           System.Directory (listDirectory, getCurrentDirectory, 
                                    createDirectory, removeFile)
---Import Text and Web Module for Web Functionality and Text Conversions                                
import           Web.Scotty
import qualified Data.Text.Lazy as T
--Module for IO Functionality in correspondance with Actions
import           Control.Monad.IO.Class (liftIO)

----Module for Datatype Conversions
import qualified DatatypeConvertersHgrade as DTC

----Removes File Extension ".txt" from Name
remFileExt :: String -> String
remFileExt fN = reverse (drop 4 (reverse fN))

-----Checks, if file or folder exists in list
folderOrFileExistsCheck :: String -> [String] -> Bool
folderOrFileExistsCheck _ [] = False
folderOrFileExistsCheck a (b:bs) = if (a == b) then True else folderOrFileExistsCheck a bs

--Creates Folder for Author, if it doesnt already exists
createFolder :: String -> IO ()
createFolder a = do
  putStrLn ("Checking if Author Folder exists: ")
  putStrLn (show a)
  allAuthors <- liftIO (listDirectory "data")
  if (not (folderOrFileExistsCheck a allAuthors)) 
    then createDirectory ("data/" ++ a) 
    else putStrLn ("Author already has folder")

--Removes old Grades of grader in defined Author, if it already exists
remOldGrades :: String -> String -> IO ()
remOldGrades a g = do
  putStrLn ("Checking if Grader already graded: " ++ (show g) ++ (" on ") ++ (show a))
  allGraders <- listDirectory ("data/" ++ a)
  putStrLn ("All Graders of " ++ a ++ ": ")
  putStrLn (show allGraders)
  if (folderOrFileExistsCheck (g ++ ".txt") allGraders) 
    then removeFile ("data/" ++ a ++ "/" ++ g ++ ".txt") 
    else putStrLn ("Grader has no old Grades")

--Creates new File for grader and inserts the new grades
createFile :: String -> String -> [Param] -> IO ()
createFile a g ps = do
  let gradesFilePath = ("data/" ++ a ++ "/" ++ g ++ ".txt") :: String
  let criteriaOnly = DTC.cutHeadOfTupleList (DTC.cutFirstTwoOfList (DTC.paramListToTupleList ps))
  writeFile gradesFilePath (show (DTC.stringListToIntList criteriaOnly))