{-# LANGUAGE OverloadedStrings #-}

--Hgrade module --> From here all other modules get called
module Hgrade where

--Module for Web Functionality
import           Web.Scotty
--Module for IO Functionality in correspondance with Actions
import           Control.Monad.IO.Class (liftIO)
--Logger
import           Network.Wai.Middleware.RequestLogger ( logStdoutDev )
--Module for correct Text packing and unpacking
import qualified Data.Text.Lazy as T
--Module for List handling
import           Data.List (sort)
--Directory Management
import           System.Directory (listDirectory, getCurrentDirectory, createDirectory, removeFile)
--Module for Datatype Conversions
import qualified DatatypeConvertersHgrade as DTC
--Module for Directory Functions
import qualified DirHgrade as DH

-------------List of all Ratings Criteria
criteriaList :: [String]
criteriaList = ["N1", "N2", "F1", "F2", "F3"];

----------Main function --> Gets called from Main.hs
main :: IO ()
main = do
  putStrLn "Good Luck!"
  scotty 4000 $ do
    middleware logStdoutDev
    
    --GET: Home Page --> Main/Index Page
    get "/" indexHtml

    --GET: Author overview Page
    get "/authors" $ do
      filenames <- liftIO (listDirectory "data")
      overviewAuthorsHtml filenames

    --GET: Author ratingspage
    get "/authors/:authorname" $ do
      authorName <- param "authorname"
      graders <- liftIO $ listDirectory ("data/" ++ authorName)
      grades <- liftIO (mapM (readGrades authorName) graders)
      let intGrades = map DTC.stringToIntList grades
      let floatGrades = map (map DTC.convertIntToFloat) intGrades
      authorRatingHTML graders authorName intGrades floatGrades

    --GET: Grad submission page
    get "/grade" submitGradesHTML

    --POST: Grade submission
    post "/grade" $ do
      author <- param "author"
      grader <- param "grader"
      criteriaParams <- params
      liftIO $ DH.createFolder author
      liftIO $ DH.remOldGrades author grader
      liftIO $ DH.createFile author grader criteriaParams
      redirect "/authors"

-------------HTML Site Functions

--HTML Index Page Creation
indexHtml :: ActionM () 
indexHtml = html (T.pack (createHTMLElement "body" 
  ((createHTMLElement "h1" "Hgrade - Peergrading in Haskell" "") ++ 
  (newLine) ++ 
  (createHTMLElement "ul" 
    ((createHTMLElement "li" 
      (createHTMLElement "a" "Grading Overview" "href='/authors'") 
    "") ++ 
    (createHTMLElement "li" 
      (createHTMLElement "a" "Submit Grading" "href='/grade'")) 
    "")) 
  "") 
  ""))

--HTML Author Overview Page Creation
overviewAuthorsHtml :: [FilePath] -> ActionM()
overviewAuthorsHtml filenames = html (T.pack ((createHTMLElement "h1" "Authors" "") ++ (createHTMLElement "ul" (createAuthorLinks filenames) "")))

--HTML Author Ratings Page Creation
authorRatingHTML :: [String] -> String -> [[Int]] -> [[Float]] -> ActionM()
authorRatingHTML graders authorName grades floatGrades = html (T.pack (
  ---------------------Style Header
  (createHTMLElement "style" (
    "table, th, td { border: 1px solid black; border-collapse: collapse; }"
  ) "") ++
  ---------------------Title
  (createHTMLElement "h1" ("Author: " ++ authorName) "") ++
  ----------------------Table
  (createHTMLElement "table" 
    --------------------------------Header Row
    ((createHTMLElement "tr" (
      (createHTMLElement "th" " " "") ++
      createTableCriteriaHeader criteriaList) "") ++
    -------------------------------------------All other Rows
      createGradeRows graders grades ++
    -------------------------------------Create Median Row
    (createHTMLElement "tr" (
      (createHTMLElement "td" "Median" "") ++
      createMedianRow (map calcMedian (map sort (rowToCol floatGrades)))
    ) "") ++
    ------------------------------------------Create Histogram Row
    (createHTMLElement "tr" (
      (createHTMLElement "td" "Histograms" "") ++
      createHTMLHistograms (rowToColInt grades) (length grades)
    ) "")
    )
  "")
  )) 

--HTML Grade submission Page Creation
submitGradesHTML :: ActionM()
submitGradesHTML = html (T.pack (createHTMLElement "body" ( 
  (createHTMLElement "h1" "Grades" "") ++
  (createHTMLElement "form" (
    (createHTMLElement "div" ( (createHTMLElement "label" "Author: " "for='authorID'") ++ createHTMLElement "input" "" "id='authorID' type='text' name='author' required='true'") "") ++
    (createHTMLElement "div" ((createHTMLElement "label" "Grader: " "for='graderID'") ++ createHTMLElement "input" "" "id='graderID' type='text' name='grader' required='true'") "") ++
    (createCriteriaRows_gradeSubmission criteriaList) ++
    (createHTMLElement "input" "" "type='submit' value='send'")) "action='/grade' method='post'")
  ) ""))

-----------------------------HTML Generators --> With those we create strings in HTML Language

--Making a break --> Creating a new Line
newLine :: String
newLine = endTag "br"

--Create an HTML Element
createHTMLElement :: String -> String -> String -> String
createHTMLElement element value par = startTag element par ++ value ++ endTag element

--Create a starttag of an HTML Element
startTag :: String -> String -> String
startTag name par = "<" ++ name ++ " " ++ par ++ ">"

--Create an endtag for an HTML Element
endTag :: String -> String
endTag name = "</" ++ name ++ ">"

--Create White Cells for the Histogramm
createWhiteHistogrammCell :: String
createWhiteHistogrammCell = createHTMLElement "td" "" "bgcolor='white' style='height:20px;width:20px'"

--Create Black Cells for the Histogramnm
createBlackHistogrammCell :: String
createBlackHistogrammCell = createHTMLElement "td" "" "bgcolor='black' style='height:20px;width:20px'"

--Create the criteria Header List of the author Ratings page
createTableCriteriaHeader :: [String] -> String
createTableCriteriaHeader [] = ""
createTableCriteriaHeader (a:as) = (createHTMLElement "th" a "") ++ createTableCriteriaHeader as

--Create the Histograms HTML String
createHTMLHistograms :: [[Int]] -> Int -> String
createHTMLHistograms [] _ = ""
createHTMLHistograms _ 0 = ""
createHTMLHistograms (a:as) l = (createHTMLElement "td" (
  (createHTMLElement "table" (
  (createHistogramCells (histogram a (0,0,0)) l)) "")) "") ++ (createHTMLHistograms as l)

--Create Input type=text HTML field
createHTMLInputText :: String -> String
createHTMLInputText a = createHTMLElement "Input" "" ("type=text required='true' name='" ++ a ++ "' id='" ++ a ++ "ID'") 

--Create all criteria Rows for the grade submission page
createCriteriaRows_gradeSubmission :: [String] -> String
createCriteriaRows_gradeSubmission [] = ""
createCriteriaRows_gradeSubmission (a:as) = (
  (createHTMLElement "div" (
   ((createHTMLElement "label" (a ++ ": ") ("for='" ++ a ++ "ID'") ) ++ createHTMLInputText a) 
  ) "")
  ) ++ createCriteriaRows_gradeSubmission as

-----------------------------Misc

--Transpose Matrix --> Datatype Float
rowToCol :: [[Float]] -> [[Float]]
rowToCol [] = []
rowToCol [[]] = [[]]
rowToCol (a:as)
            | ((length a) > 1) = (map head (a:as)) : rowToCol (map tail (a:as))
            | otherwise = [(map head (a:as))]

--Transpose Matrix --> Datatype Int
rowToColInt :: [[Int]] -> [[Int]]
rowToColInt [] = []
rowToColInt [[]] = [[]]
rowToColInt (a:as)
            | ((length a) > 1) = (map head (a:as)) : rowToColInt (map tail (a:as))
            | otherwise = [(map head (a:as))]

--Calculate the Median
calcMedian :: [Float] -> Float
calcMedian [] = 0
calcMedian (a:[]) = a
calcMedian (a:b:[]) = (a + b) / 2
calcMedian (_:b:_:[]) = b
calcMedian as
          | null as  = 0
          | odd  (length as) = (as !! oddMiddle)
          | even (length as) = ((as !! evenMiddle + as !! (evenMiddle+1)) / 2)
                where oddMiddle =  ((length as) `div` 2)
                      evenMiddle = ((length as) `div` 2) - 1

-------------------Author Overview Functions
--Create the Links to all the different authors
createAuthorLinks :: [FilePath] -> String
createAuthorLinks [] = ""
createAuthorLinks (a:as) = createListElement a ++ createAuthorLinks as

--Create an HTML "li" element (List Element)
createListElement :: String -> String
createListElement value = createHTMLElement "li" ((createHTMLElement "a" value ("href=/authors/" ++ value))) ""

-------------------Author Rating Functions --> Functions for the rating page
--Function for reading the grades from fs
readGrades :: String -> String -> IO String
readGrades authorName grader = readFile ("data/" ++ authorName ++ "/" ++ grader)

--Create the rows with the grader and all the data
createGradeRows :: [String] -> [[Int]] -> String
createGradeRows _ [] = ""
createGradeRows [] _ = ""
createGradeRows (grader:restGraders) (grades: restGrades) = ((createHTMLElement "tr" (
  (createHTMLElement "td"
  (DH.remFileExt grader) "") ++
  (createGradeCell grades)) "" ) ++ 
  createGradeRows restGraders restGrades)
  
--Create the Cells, within are the grades
createGradeCell :: [Int] -> String
createGradeCell [] = []
createGradeCell (a:as) = createHTMLElement "td" (show a) "" ++ createGradeCell as

--Create the row, where we put the median
createMedianRow :: [Float] -> String
createMedianRow [] = []
createMedianRow (a:as) = createHTMLElement "td" (show a) "" ++ createMedianRow as

--Compute the data for the histogram
histogram :: [Int] -> (Int, Int, Int) -> (Int, Int, Int)
histogram [] (x,y,z) = (x,y,z)
histogram (a:as) (x,y,z)
              | (a == 0) = histogram as ((x+1), y, z)
              | (a == 1) = histogram as (x, (y + 1), z)
              | (a == 2) = histogram as (x, y, (z + 1))

--Create the HistogramCells --> It checks if it needs to put a black or a white Background Cell
createHistogramCells :: (Int, Int, Int) -> Int -> String
createHistogramCells (0, 0, 0) (0) = ""
createHistogramCells (x, y, z) l = 
  (if (l <= 1) then "" else ( createHistogramCells (x-1, y-1, z-1) (l-1) )) ++ 
  (createHTMLElement "tr" (
  (if (x > 0) then createBlackHistogrammCell else createWhiteHistogrammCell) ++
  (if (y > 0) then createBlackHistogrammCell else createWhiteHistogrammCell) ++
  (if (z > 0) then createBlackHistogrammCell else createWhiteHistogrammCell)) "")