{-# LANGUAGE OverloadedStrings #-}

--Datatype Converter Functions of Hgrade
module DatatypeConvertersHgrade where

---Import Text and Web Module for Web Functionality and Text Conversions
import           Web.Scotty
import qualified Data.Text.Lazy as T

--Convert a String to a List of Ints
stringToIntList :: String -> [Int]
stringToIntList [] = []
stringToIntList xs = read xs :: [Int]

--Convert a List of Strings to a List of Ints
stringListToIntList :: [String] -> [Int]
stringListToIntList [] = []
stringListToIntList xs = map ( \x -> read x :: Int ) xs

--Convert an int to a float
convertIntToFloat :: Int -> Float
convertIntToFloat a = fromIntegral a :: Float

--Cut the first two Elements out of a list
cutFirstTwoOfList :: [a] -> [a]
cutFirstTwoOfList [] = []
cutFirstTwoOfList (a:b:abs) = abs

--Give in a List of Tuples --> Give back a List of the second tuples of every Tuple
cutHeadOfTupleList :: [(String, String)] -> [String]
cutHeadOfTupleList as = map giveBackSecondPartOfTuple as

--Give back second part of tuple
giveBackSecondPartOfTuple :: (String, String) -> String
giveBackSecondPartOfTuple (_, b) = b

--Convert a list of params into a List of tuples
paramListToTupleList :: [Param] -> [(String, String)]
paramListToTupleList [] = []
paramListToTupleList as = map paramToTuple as

--Convert a param into a tuple
paramToTuple :: Param -> (String, String)
paramToTuple (a, b) = (((T.unpack (a)) :: String), ((T.unpack b) :: String))  