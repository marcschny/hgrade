-----------------------------------------------------------------------------
-- |
-- Module      :  Hgrade
--
-- Main module of the application. Launches scotty and handles all requests.
--
-----------------------------------------------------------------------------
{-# LANGUAGE OverloadedStrings #-}

module Hgrade where

import Network.Wai.Middleware.RequestLogger (logStdoutDev)
import Web.Scotty
import System.Environment
import System.Exit
import Hgrade.Routes as Routes
import Hgrade.FileIO as FileIO

-- | List of grading criteria.
criteria :: [String]
criteria  = ["N1", "N2", "N3", "F1", "F2", "F3", "F4"]

-- | Defines routes and forwards requests to methods of the Route module.
main :: IO ()
main = do
  getArgs >>= parseParams
  scotty 4000 $ do
    middleware logStdoutDev

    get "/" Routes.indexHtml

    get "/static/styles.css" $ file "static/styles.css"
    
    get "/authors" Routes.authorsHtml

    get "/authors/:author" $ do
      author_id <- param "author"
      Routes.fetchAuthor author_id criteria

    get "/grade" $ do
      Routes.gradeHtml criteria

    post "/grade" $ do
      p <- params
      let paramObj = if null p then [] else p
      let entity = map (\(_,value) -> value) paramObj
      
      Routes.createEntity entity
      redirect "/"

-- | Parses the passed parameters.
parseParams :: [String] -> IO ()
parseParams []        = return ()
parseParams ["-demo"] = FileIO.populateWithData criteria
parseParams _         = putStrLn "Invalid args, stopping...\n\nValid parameters:\n\t-demo\tGenerates demo files" >> exitWith (ExitFailure 1)