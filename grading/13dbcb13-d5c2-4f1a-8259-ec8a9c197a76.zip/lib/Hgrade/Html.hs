-----------------------------------------------------------------------------
-- |
-- Module      :  Hgrade.Html
--
-- Definition for the data type HTML and the function to render to HTML String.
--
-----------------------------------------------------------------------------

module Hgrade.Html (
  body,
  HTML (..),

) where

import Data.List (intercalate)

-- | Representation for most HTML tags.
data HTML
  = DIV String [HTML] 
  | H1 String
  | H2 String
  | H3 String
  | H4 String
  | P String
  | UL [HTML]
  | LI [HTML]
  | TH [String]
  | TR [HTML]
  | TD String String
  | TABLE String [HTML]
  | A String String
  | FORM [HTML] String String
  | LABEL String String
  | INPUT String String String
  | HISTOGRAM HTML
  | NONE

-- | Defines a show instance for the data type. Uses renderHTML for convenience.
instance Show HTML where
    show = renderHTML

-- | Serializes an entire html document to a single String.
body :: [HTML] -> String
body tags = addBrackets "link" (addAttributes [("rel","preconnect"),("href","https://fonts.gstatic.com")]) "" ++ 
            addBrackets "link" (addAttributes [("href","https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;600&display=swap")]) "" ++
            addBrackets "link" (addAttributes [("rel","stylesheet"), ("href","/static/styles.css")]) "" ++
            intercalate "" (map renderHTML tags)  

-- | Serializes an object of type 'HTML' to a String.
renderHTML :: HTML -> String
renderHTML (DIV s as)                   = addBrackets "div" (addAttributes [("id",s)]) $ intercalate "" (map renderHTML as)
renderHTML (H1 s)                       = addBrackets "h1" "" s
renderHTML (H2 s)                       = addBrackets "h2" "" s
renderHTML (H3 s)                       = addBrackets "h3" "" s
renderHTML (H4 s)                       = addBrackets "h4" "" s
renderHTML (P s)                        = addBrackets "p" ""  s
renderHTML (A ref title)                = addBrackets "a" (addAttributes[("href", ref)]) title
renderHTML (LI items)                   = addBrackets "li" "" $ intercalate "" (map renderHTML items)
renderHTML (UL items)                   = addBrackets "ul" "" $ intercalate "" (map renderHTML items)
renderHTML (TH items)                   = addBrackets "tr" "" $ intercalate "" ((addBrackets "th" "" "") : (map (\x -> addBrackets "th" "" x) items))
renderHTML (TR s)                       = addBrackets "tr" "" $ intercalate "" (map renderHTML s)
renderHTML (TABLE identity s)           = addBrackets "table" (addAttributes [("id",identity)]) $ intercalate "" (map renderHTML s)
renderHTML (TD identity s)              = addBrackets "td" (addAttributes [("id",identity)]) s 
renderHTML (FORM items a m)             = addBrackets "form" (addAttributes [("action",a),("method", m)]) $ intercalate "" (map renderHTML items)
renderHTML (LABEL f s)                  = addBrackets "label" (addAttributes [("for",f)]) s
renderHTML (INPUT "submit" _ _)         = addBrackets "input" (addAttributes [("type","submit"),("value", "Submit")]) ""
renderHTML (INPUT "number" a b)         = addBrackets "input" (addAttributes [("type","number"),("id", "quantity"), ("name", "quantity"),("min", a), ("max",b)] ++ " required") ""
renderHTML (INPUT t s name)             = addBrackets "input" (addAttributes [("type", t),("id", s), ("name", name)] ++ " required") ""
renderHTML (HISTOGRAM hs)               = addBrackets "td" "" (renderHTML hs)
renderHTML (NONE)                       = addBrackets "div" "" ""

-- | Creates a valid html tag by enclosing the passed parameters in brackets.
addBrackets :: String -> String -> String -> String
addBrackets tag params content  = "<" ++ tag ++ (if params /= "" then " " else "") ++ params ++ ">" ++ content ++ "</" ++ tag ++ ">"

-- | Creates a single string with all attributes of a single html element.
addAttributes :: [(String, String)] -> String
addAttributes as = intercalate " " $ map (\(x,y) -> x ++ "=\"" ++ y ++ "\"") as