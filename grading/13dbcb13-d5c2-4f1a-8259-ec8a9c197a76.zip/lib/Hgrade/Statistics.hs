-----------------------------------------------------------------------------
-- |
-- Module      :  Hgrade.Statistics
--
-- Contains analytical methods used in histogram and median generation.
--
-----------------------------------------------------------------------------

module Hgrade.Statistics (
    colsToRows, 
    histogram, 
    generateHistogram,
    median,

) where

import Data.List (sort)

-- | Transposes any rectangular matrix.
-- Does not work with jaggy matrices.
colsToRows :: [[a]] -> [[a]]
colsToRows ([]:_) = []
colsToRows as = (map head as) : colsToRows (map tail as)

-- | Computes the median of a list. Throws an error if 'as' is empty.
-- It's unclean but correct in the sense that the median for an empty 
-- list is undefined.
median :: (Ord a, Fractional a) => [a] -> a
median as | odd n = sort as !! (n `div` 2)
          | even n = ((sort as !! (n `div` 2 - 1)) + (sort as !! (n `div` 2))) / 2
          | otherwise = 0.0
          where n = length as

-- | Counts the frequency of 0's, 1's, and 2's 
-- respectively and constructs a triplet. Returns (0,0,0) for empty lists,
-- such that an empty histogram will be created.
histogram :: [Int] -> (Int,Int,Int)
histogram [] = (0,0,0)
histogram is = (count 0 is,count 1 is,count 2 is)

-- | Helper method to count all occurences of 'x' in a list.
count :: Eq a => a -> [a] -> Int
count x = length . filter (x==)

-- | Takes a triplet and creates an [[Int]]. This is a helper method for
-- constructing the HTML representation of the histogram.
generateHistogram :: (Int, Int, Int) -> [[Int]]
generateHistogram (a,b,c) = 
    let i = sum [a,b,c]
    in let x = take (i-a) (repeat 0) ++ take a (repeat 1)
    in let y = take (i-b) (repeat 0) ++ take b (repeat 1)
    in let z = take (i-c) (repeat 0) ++ take c (repeat 1)
    in colsToRows [x,y,z]

