-----------------------------------------------------------------------------
-- |
-- Module      :  Hgrade.FileIO
--
-- Various methods related to File and I/O. Used for reading directories/files
-- as well as writing to files.
-----------------------------------------------------------------------------

module Hgrade.FileIO(
     readFileNames,
     readFiles, 
     populateWithData, 
     writeToFile,

) where

import System.Directory
import System.Random
import System.IO.Error
import Control.Exception
import Control.Monad (replicateM)

-- | Reads the contents of the directory specified. Excludes "." and "..".
readFileNames :: FilePath -> IO [String]
readFileNames path = do
                 exists <- doesDirectoryExist path
                 if not exists then return []
                 else do
                     content <- getDirectoryContents path
                     let authors = if null content then [] else content
                     return $! filter (flip notElem ["..","."]) authors

-- | Reads all files specified into a list.
readFiles :: [FilePath] -> IO [String]
readFiles = mapM readFile

-- | Writes to a file. Creates directories and subdirectories if necessary.
writeToFile :: String -> String -> String -> IO ()
writeToFile author grader value = do
                createDirectoryIfMissing False ("data/")
                let filename = "data/" ++ author ++ "/" ++ grader ++ ".txt"
                createDirectoryIfMissing False ("data/" ++ author)
                writeFile filename value

-- | Creates demo files. If 'data/' exists,
-- it is deleted before new files are created.
populateWithData :: [String] -> IO ()
populateWithData criteria = do
                dataExists <- doesDirectoryExist "data/"
                let exists = dataExists
                rng <- generateRandoms 4 8 1
                let b = if null rng then [] else rng
                if exists then do
                          putStrLn "Removing data/ directory"
                          removeIfExists "data/"
                          putStrLn "Creating Demo files"
                          randomizeAuthors (head b) $ length criteria
                     else do
                          putStrLn "Creating Demo files"
                          randomizeAuthors (head b) $ length criteria

-- | Generates 'count' random authors with a randomly generated amount of graders.
randomizeAuthors :: Int -> Int -> IO ()
randomizeAuthors 0 _ = return ()
randomizeAuthors count nrOfCriterias = do
                  randomNumbers <- generateRandoms 4 8 1
                  let rng = if null randomNumbers then [] else randomNumbers
                  randomizeGraders count nrOfCriterias $ head rng
                  randomizeAuthors (count-1) nrOfCriterias 

-- | Generates 'count' random graders with random grading data.
randomizeGraders :: Int -> Int -> Int -> IO ()
randomizeGraders _ _ 0 = return ()
randomizeGraders current nrOfCriterias count = do
                           randomNumbers <- generateRandoms 0 2 nrOfCriterias
                           let rng = if null randomNumbers then [] else randomNumbers
                           writeToFile ("author" ++ (show current))  ("grader" ++ (show count)) (show rng)
                           randomizeGraders current nrOfCriterias (count-1)

-- | Returns a list with 'count' randomly generated numbers. 
generateRandoms :: Int -> Int -> Int -> IO [Int]
generateRandoms from to count = replicateM count (randomRIO (from,to) :: IO Int)

-- | Removes the contents at the given path forcibly.
removeIfExists :: FilePath -> IO ()
removeIfExists path = removePathForcibly path `catch` alreadyExists
  where alreadyExists e
          | isDoesNotExistError e = return ()
          | otherwise = throwIO e