-----------------------------------------------------------------------------
-- |
-- Module      :  Hgrade.Routes
--
-- Methods for handling route requests.
--
-----------------------------------------------------------------------------

module Hgrade.Routes (
  indexHtml,
  authorsHtml,
  gradeHtml,
  fetchAuthor,
  createEntity
) where

import Web.Scotty
import qualified Data.Text.Lazy as T
import qualified Hgrade.Html as Html
import qualified Hgrade.Statistics as Statistics
import qualified Hgrade.FileIO as FileIO
import Control.Monad.IO.Class(liftIO)

-- | Returns the root html. ("/")
indexHtml :: ActionM ()
indexHtml =
  html
    ( T.pack
        ( Html.body
            [ Html.H1 "Hgrade",
              Html.UL
                [ Html.LI [Html.A "/authors" "Grading Overview"],
                  Html.LI [Html.A "/grade" "Submit Grading"]
                ]
            ]
        )
    )

-- | Returns the html with the list of all authors. ("/authors")
authorsHtml :: ActionM ()
authorsHtml = do
            authors <- liftIO $ FileIO.readFileNames "data/"
            let authorList = if null authors then [] else authors
            let htmls = map (\x -> Html.LI [Html.A ("/authors/" ++ x) x]) authorList
            html (T.pack (Html.body [Html.H1 "Grading Overview", Html.UL htmls]))

-- | Takes all criterias and returns the html form to grade an author. ("/grade")
gradeHtml :: [String] -> ActionM ()
gradeHtml criteria = do
                      let grader = Html.DIV "form-items" [Html.LABEL "grader" "Grader", Html.INPUT "text" "grader" "grader"]
                      let author = Html.DIV "form-items" [Html.LABEL "author" "Author", Html.INPUT "text" "author" "author"]

                      let criteriaHeader = Html.DIV "form-criteria" [Html.LABEL "criteria" "Criteria"] 
                      let formRows = map (\c -> Html.DIV "form-items" [Html.LABEL c c, Html.INPUT "number""0" "2"] ) criteria
                      let submitBtn = Html.DIV "form-items" [Html.INPUT "submit" "" ""]

                      let form = formRows 
                      let finalForm = Html.FORM ([author, grader, criteriaHeader] ++ form ++ [submitBtn]) "/grade" "post"
                      html (T.pack (Html.body [Html.H1 "Grade", finalForm]))

-- | Returns the html page with the table containing all data on that author. ("/authors/:author")
fetchAuthor :: String -> [String] -> ActionM()
fetchAuthor author criteria = do
                               let pageTitle = Html.H1 ("Author: " ++ author)

                               directoryContent <- liftIO $ FileIO.readFileNames $ "data/" ++ author
                               let fileNames = if null directoryContent then [] else directoryContent

                               -- Author has no graders
                               if (length fileNames) == 0 then html ( T.pack (Html.body [pageTitle, Html.H4 "No Graders found"]))
                               
                               -- Author has graders
                               else do
                                    let filePaths = map (\s -> "data/" ++ author ++ "/" ++ s) fileNames
                                    let graderNames = map (init . init . init . init) fileNames
                                    let graderTDs = map (\el -> [Html.TD "" el]) graderNames

                                    contents <- liftIO $ FileIO.readFiles (filePaths)
                                    let fileContents = if null contents then [] else contents

                                    let parsedContents = map (\i -> read i::[Int]) fileContents

                                    let colsrows = Statistics.colsToRows parsedContents

                                    let medianTitle = Html.TD "median" "Median"
                                    let medians = map (Statistics.median) (map (map (fromIntegral)) colsrows)
                                    let medianHTML = map (\ele -> Html.TD "median" (show ele)) medians
                                    let medianLine = medianTitle : medianHTML
                                    let medianRow = Html.TR medianLine

                                    let tableColumns = map (\item -> map(\inner -> Html.TD "" (show inner)) item) parsedContents
                                    let tableLine = zipWith(++) graderTDs tableColumns

                                    let tableRows = map (\a -> Html.TR a) tableLine
                                    
                                    let fillerRow = Html.TR (take ((length criteria) + 1) (repeat (Html.TD "filler" ""))) -- for styling purposes only

                                    let histogramTitle = [Html.TD "" "Histogram"]

                                    let histogramInfo = map Statistics.histogram colsrows -- FORM : [(Int, Int, Int),(Int, Int, Int)]
                                    let histogramRawData = map Statistics.generateHistogram histogramInfo -- FORM: [[[0,0,0],[1,1,0]],[[0,0,1],[0,0,1]]]

                                    let tdGraph = map (\el -> Html.TABLE "histogram" (map (parseHistogramRows) el)) histogramRawData
                                    let sample = map(\i -> Html.HISTOGRAM i) tdGraph
                                    let finalHist = histogramTitle ++ sample

                                    let histogramRow = Html.TR finalHist

                                    let table = Html.TABLE "" $ Html.TH criteria : tableRows ++ [medianRow] ++ [fillerRow] ++ [histogramRow]
                                    html ( T.pack (Html.body [pageTitle, table]))

-- | Constructs the grading object and saves it to a file
createEntity ::  [T.Text] -> ActionM()
createEntity b = do 
                let strings = map T.unpack b
                let grader = head . drop 1 $ strings
                let author = head strings
                let values = map(\x -> read x::Int) $ drop 2 strings
                liftIO $ FileIO.writeToFile author grader $ show values

-- | Translates a list to a TR element in the histogram.
parseHistogramRows :: [Int] -> Html.HTML
parseHistogramRows [0,0,0] = Html.TR [Html.TD "clear"   "", Html.TD "clear"   "", Html.TD "clear"   ""]
parseHistogramRows [1,0,0] = Html.TR [Html.TD "colored" "", Html.TD "clear"   "", Html.TD "clear"   ""]
parseHistogramRows [0,1,0] = Html.TR [Html.TD "clear"   "", Html.TD "colored" "", Html.TD "clear"   ""]
parseHistogramRows [0,0,1] = Html.TR [Html.TD "clear"   "", Html.TD "clear"   "", Html.TD "colored" ""]
parseHistogramRows [1,1,0] = Html.TR [Html.TD "colored" "", Html.TD "colored" "", Html.TD "clear"   ""]
parseHistogramRows [0,1,1] = Html.TR [Html.TD "clear"   "", Html.TD "colored" "", Html.TD "colored" ""]
parseHistogramRows [1,0,1] = Html.TR [Html.TD "colored" "", Html.TD "clear"   "", Html.TD "colored" ""]
parseHistogramRows [1,1,1] = Html.TR [Html.TD "colored" "", Html.TD "colored" "", Html.TD "colored" ""]
parseHistogramRows _       = Html.NONE