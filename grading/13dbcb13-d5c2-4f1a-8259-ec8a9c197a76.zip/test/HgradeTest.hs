module Main (main) where

import Hgrade.Statistics(colsToRows, median, histogram)
import Test.Tasty
import Test.Tasty.HUnit

-- | Invokes the execution of all tests.
main :: IO ()
main = defaultMain tests

-- | Combines all TestTrees.
tests :: TestTree
tests = testGroup "Unit tests" [colsToRowsTest, medianTest, histogramTest]

-- | Tests the 'colsToRows' method in 'Hgrade.Statistics'.
colsToRowsTest :: TestTree
colsToRowsTest =
  testGroup
    "colsToRows test"
    [ testCase "transpose column vector" $
        colsToRows [[0],[1]] @?= [[0, 1]],
      testCase "transpose row vector" $
        colsToRows [[0,1]] @?= [[0],[1]],
      testCase "transpose 2x2 matrix" $
        colsToRows [[0,1],[2,3]] @?= [[0,2],[1,3]],
      testCase "transpose non-square matrix" $
        colsToRows [[1,2,3],[4,5,6]] @?= [[1,4],[2,5],[3,6]]
    ]

-- | Tests the 'median' method in 'Hgrade.Statistics'.
medianTest :: TestTree
medianTest =
  testGroup
    "median test"
    [ 
      testCase "median of list with single element" $
        median [1] @?= 1.0,
      testCase "median of list with odd number of elements" $
        median [1,3,2,5,4] @?= 3.0,
      testCase "median of list with odd number of elements" $
        median [1,4,2,3] @?= 2.5
    ]

-- | Tests the 'histogram' method in 'Hgrade.Statistics'.
histogramTest :: TestTree
histogramTest =
  testGroup
    "histogram test"
    [ testCase "histogram of empty list" $
        histogram [] @?= (0,0,0),
      testCase "median of list with single element" $
        histogram [1] @?= (0,1,0),
      testCase "histogram with long list" $
        histogram [0,2,2,2,0,1,1,2,0,2,2,0,2,1,0,2,2,0,2,1,2,0,1,2,0,1,0,0,1,2,1,0,2,2,0,2,1,1,1,0,1,2,1,0,2,1,2,0,0,2,2,1,2,2,0,0,2] @?= (18,15,24),
      testCase "histogram with elements outside of [0..2]" $
        histogram [1,5,1,0,2,24,0,1,3,1,2,0] @?= (3,4,2)
    ]
