module Main where

import qualified Hgrade

main :: IO ()
main = Hgrade.main