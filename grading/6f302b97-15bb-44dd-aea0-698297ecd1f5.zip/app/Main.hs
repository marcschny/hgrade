{-|
    This module executes the Hgrade.hs main function.
-}

module Main where

import qualified Hgrade

-- |Main function that redirects to the main function of Hgrade.hs
main :: IO ()
main = Hgrade.main