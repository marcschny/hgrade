{-|
    This module contains simple tests for the functions histogram, median and colsToRows
-}

module Main (main) where

import Hgrade.GradingTable (histogram, median)
import Hgrade.Utils (colsToRows)

import Test.Tasty
import Test.Tasty.HUnit

-- |Uses the defaultMain method to execute all tests in the "tests"-function
main :: IO ()
main = defaultMain tests

-- |Describes a test-tree and uses a String and an Array of functions (tests) that will be in the test-suite. 
tests :: TestTree
tests = testGroup "Tests" [unitTestHistogram, unitTestColsToRows, unitTestMedian]

-- |Test the histogram-function. An empty list should return zeros and a full list should return the correct triple
unitTestHistogram :: TestTree
unitTestHistogram = testGroup "Histogram Unit Tests"
  [ testCase "histogram empty list" $
      histogram [] @?= (0, 0, 0),
      
    testCase "histogram [2, 1, 0, 2, 1, 2] should be (1, 2, 3)" $
      histogram [2, 1, 0, 2, 1, 2] @?= (1, 2, 3)
  ]

-- |Test the colsToRows-function. All rows should become columns and vice verca
unitTestColsToRows :: TestTree
unitTestColsToRows = testGroup "ColsToRows Unit Tests"
  [ testCase "colsToRows [[1, 2, 3], [4, 5, 6]]" $
      colsToRows [[1 :: Int, 2, 3], [4, 5, 6]] @?= [[1 :: Int, 4], [2, 5], [3, 6]],
      
    testCase "colsToRows [[1, 2, 3, 4]]" $
      colsToRows [[1 :: Int, 2, 3, 4]] @?= [[1 :: Int], [2], [3], [4]]
  ]

-- |Test the median-function. The middle pair of numbers are used to calculate the median. 
-- |If there is an uneven number of ints in the list, the median is the middle Int.
unitTestMedian :: TestTree
unitTestMedian = testGroup "Median Unit Test"
  [ testCase "median with sorted list [1, 2, 3, 4]" $ 
      median [1, 2, 3, 4] @?= 2.5,
    
    testCase "median NO sorted list [1, 3, 4, 2]" $
      median [1, 3, 4, 2] @?= 2.5,
    
    testCase "median with oddList [1, 2, 3, 4, 5]" $
      median [1, 2, 3, 4, 5] @?= 3
    ]
