{-|
    This module contains the main function of the programm. It handles get and post mappings and also controlls
    the -- -demo case.  
-}

{-# LANGUAGE OverloadedStrings #-}

module Hgrade where

import           Web.Scotty
import           System.Directory ( createDirectoryIfMissing, listDirectory )
import           System.Environment ( getArgs ) 
import           Control.Monad.IO.Class (liftIO)
import           Network.Wai.Middleware.RequestLogger ( logStdoutDev )
import qualified Data.Text.Lazy      as T

import qualified Hgrade.HtmlElements as E
import qualified Hgrade.Constants    as C
import qualified Hgrade.Utils        as U

import qualified Hgrade.GradingTable as GT
import qualified Hgrade.GradingForm  as GF
import qualified Hgrade.DemoData     as DD

-- |Handles get and post mapping and controlls the -- -demo or normal case
main :: IO ()
main = do
  args <- getArgs
  if null args
    then pure ()
    else 
      if head args == "-demo"
        then DD.demoData
        else pure ()
  
  putStrLn "Good Luck!"
  scotty 4000 $ do
    middleware logStdoutDev
    
    -- Get the stylesheet
    get "/static/styles.css" $ file "static/styles.css"

    -- Get the front page
    get "/" indexHtml

    -- Get the author-list
    get "/authors" $ do
      liftIO (createDirectoryIfMissing False C.dataLoc)
      authors <- liftIO (listDirectory C.dataLoc)
      authorsHtml authors

    -- Get the grading-table for a chosen author
    get "/authors/:foldername" $ do
      foldername <- param "foldername"
      graderFiles <- liftIO (listDirectory (C.dataLoc ++ foldername))
      graderFilesData <- mapM (\x -> liftIO (readFile (C.dataLoc ++ foldername ++ "/" ++ x))) graderFiles
      GT.gradingTableHtml foldername graderFilesData graderFiles

    -- Get the grading-form
    get "/grade" $ do 
      GF.gradeHtml

    -- Uses params to select the author and the grader, then creates folders for the author (if missing) and (over-)writes the files for the graders
    -- After this, redirects to the authors page
    post "/grade" $ do
      author <- param "author"
      grader <- param "grader"

      paramData <- params
      let fileFormat = U.createFileFormat (U.paramsToList (tail (tail paramData)))

      liftIO $ createDirectoryIfMissing False C.dataLoc
      liftIO $ createDirectoryIfMissing False (C.dataLoc ++ author)
      liftIO $ writeFile (C.dataLoc ++ author ++ "/" ++ grader ++".txt") fileFormat

      redirect "/authors"

-- |Returns a page with a linkt to the authors-page and a link to the grading-form
indexHtml :: ActionM () 
indexHtml = 
  html (T.pack (
    E.body [
      E.h1 ["Hgrade - Peergrading in Haskell"],
      E.ul [
        E.a "/authors" ["Grading Overview"],
        E.a "/grade" ["Submit Grading"]
      ]
    ])
  )

-- |Returns a page with all authors in the data-folder. It is displayed as a linked-list, in which every author is a link to his grading table
authorsHtml :: [String] -> ActionM ()
authorsHtml authors = 
  html (T.pack (
    E.body [
      E.h1 ["Authors"],
      E.ll authors
    ])
  )
