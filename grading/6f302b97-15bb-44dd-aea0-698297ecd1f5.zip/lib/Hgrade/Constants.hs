{-|
    This module defines the location of the data-directory and the head categories, which can be dynamically changed and appear correct in the programm
-}

module Hgrade.Constants where

-- |Location of the data-folder. Is the root-folder for author-grading
dataLoc :: String
dataLoc = "data/"

-- |All grading-categories displayed in the head of the grading-table. CAN BE CHANGED, so that the programm changes the amount of grading criteria dynamically
headCategories :: [String]
headCategories = ["N1", "N2", "F1", "F2", "F3"]