{-|
    This module creates a grading table, where
      the first row is a header row that shows the grading-critera (C.headCategories)
      the next rows show the grader-data
      A median row that shows the median of all graders in the specific grading-category
      And a histogram that displays a single grading-category and shows how many graders chose to give how many points.
-}

module Hgrade.GradingTable where

import           Web.Scotty (html, ActionM)
import           System.Directory ()
import           Data.List (sort)
import qualified Data.Text.Lazy      as T

import qualified Hgrade.HtmlElements as E
import qualified Hgrade.Constants    as C
import qualified Hgrade.Utils        as U

-- |Creates a html with a head and a body. The head has a stylesheet. The body contains all the grader-data, the median and the histograms.
gradingTableHtml :: String -> [String] -> [String] -> ActionM ()
gradingTableHtml foldername graderData graderFiles = 
  html (T.pack (
    E.html [
      E.hHead [
        E.link "stylesheet" "../static/styles.css"
      ],
      E.body [
        E.h1 ["Author: ", foldername],
        E.table [
          E.tHead ("" : C.headCategories),
          U.reduceToString [gradingTableBody graderData graderFiles],
          E.tr [
            E.td "Median",
            U.reduceToString (map ((E.td . show) . median) (U.colsToRows (map U.stringToIntArray graderData)))
            ], 
          E.tr [
            E.td "Histogram",
            U.reduceToString (map E.td (histogramList (U.stringsToIntArrays graderData)))
            ]
        ]
      ]
    ])
  )

-- |Takes an Array of graderData [String] and an Array of graderFiles [String]. The graderFiles get cut at the "." of grader.txt so only
-- |the grader-name remains. The rest is used to create the values for each grader. This is done recursively done to create the whole table
gradingTableBody :: [String] -> [String] -> String
gradingTableBody = r_gr ""
  where r_gr acc [] []         = acc
        r_gr acc _  []         = acc
        r_gr acc [] _          = acc
        r_gr acc (x:xs) (y:ys) = 
            r_gr (acc ++ E.tr [E.td (takeWhile (/= '.') y) ++ 
            gradingTableData (U.stringToIntArray x)]) xs ys

-- |Takes an Int Array [Int] and returns a string that consists of td-elements in which each is a value of the Int-Array 
gradingTableData :: [Int] -> String
gradingTableData xs = U.reduceToString (map (E.td . show) xs)

-- |Takes an array of Int-Arrays [[Int]] and returns an Array of Strings [String]. Each String in the output-array is a histogram
histogramList :: [[Int]] -> [String]
histogramList xss = map (drawHistogram . histogram) (U.colsToRows xss)

-- |Takes a histogram-triple (Int, Int, Int) and returns a string that represents the histogram with html-tags.
-- |To calculate is a square is white or black, the height of the final histogram is calculated (c). Then, the triple
-- |is converted to an array of the triple-values (x, y, z), where the values of the array are [c - x, c - y, c - z].
-- |with the drawHisRow-function: If a value is > 0, a white square is drawn and vice versa. With this strategy,
-- |the height (c) is counted down until it reaches 0 and the histogram is drawn. 
drawHistogram :: (Int, Int, Int) -> String
drawHistogram o = r_dh (E.ohtml "table") (U.tripleSum o) o
  where r_dh acc 0 _ = acc ++ E.chtml "table"
        r_dh acc c (x, y, z) = r_dh (acc ++ drawHisRow [c - x, c - y, c - z]) (c-1) (x, y, z)

-- |Takes an Int Array [Int] and creates a tableRow tr (String), where, if the Int-Values is above 0, a white square is appended
-- |and if the Int-Value is 0 or below, a black square is appended.
drawHisRow :: [Int] -> String
drawHisRow = r_dhr (E.ohtml "tr")
  where r_dhr acc []     = acc ++ E.chtml "tr"
        r_dhr acc (x:xs)
          | x > 0     = r_dhr (acc ++ E.atd "white" "height:20px;width:20px") xs
          | otherwise = r_dhr (acc ++ E.atd "black" "height:20px;width:20px") xs

-- |Takes an Int Array [Int] that has, per definition the numbers 0 1 2, and returns a triple, where
-- |  the first  element of the triple is the number of 0's in the array
-- |  the second element of the triple is the number of 1's in the array
-- |  the third  element of the triple is the number of 2's in the array
histogram :: [Int] -> (Int, Int, Int)
histogram [] = (0, 0, 0)
histogram xs = 
  (length (filter (==0) xs), 
   length (filter (==1) xs),
   length (filter (==2) xs))

-- |Takes an Int Array [Int] and returns the median of the SORTED array.
median :: [Int] -> Double
median xs
  | null xs         = 0
  | even (length xs) = evenMedianList (sort xs)
  | otherwise        = oddMedianList (sort xs)

-- |If the Int Array has an even number of Int's, take the middle two Ints and return their average
evenMedianList :: [Int] -> Double
evenMedianList xs
  | length xs == 2 = fromIntegral (head xs + head (tail xs)) / 2
  | otherwise      = evenMedianList (tail (init xs))

-- |If the Int Array has an odd number of Int's, return the middle Int
oddMedianList :: [Int] -> Double
oddMedianList xs
  | length xs == 1 = fromIntegral (head xs)
  | otherwise      = oddMedianList (tail (init xs))