{-|
    This module contains all html-tags needed for the projekt. Most of the tags use [String] as input and
    output a string in html-style without using the close-tag twice.
-}

module Hgrade.HtmlElements where

import qualified Hgrade.Utils as U


--- HTML Open and Close ---

-- |Open-Html: wraps a String with an Open-Html-Tag
ohtml :: String -> String
ohtml s = "<" ++ s ++ ">"

-- |Close-Html: wraps a String with a Close-Html-Tag
chtml :: String -> String
chtml s = "</" ++ s ++ ">"

-- |Open-Close-Html: wraps a String with both Html-Tags
ochtml :: String -> String -> String
ochtml t s = (ohtml t ++ s) ++ chtml t 


--- HTML Attributes ---

-- |For attribute for a label
aFor :: String -> String
aFor s = "for='" ++ s ++ "'" 

-- |Type attribute for an input
aType :: String -> String
aType s = "type='" ++ s ++ "'"

-- |Id attribute for an input
aId :: String -> String
aId s = "id='" ++ s ++ "'" 

-- |Name attribute for an input
aName :: String -> String
aName s = "name='" ++ s ++ "'" 

-- |Action attribute for a form. Defines the link to the post API
aAction :: String -> String
aAction s = "action='" ++ s ++ "'"

-- |Method attribute for a form. Can be "get" or "post"
aMethod :: String -> String
aMethod s = "method='" ++ s ++ "'"

-- |First attribute of a link (Rel File Path / Name)
aRel :: String -> String
aRel s = "rel='" ++ s ++ "'"

-- |Second attribute of a link (File Path)
aHref :: String -> String
aHref s = "href='" ++ s ++ "'"

-- |Color attribute of a html tag
aBgcolor :: String -> String
aBgcolor s = "bgcolor='" ++ s ++ "'"

-- |Style attribute of a html tag
aStyle :: String -> String
aStyle s = "style='" ++ s ++ "'"


--- HTML Elements ---

-- |Takes a list of strings and wraps it in a html-tag
html :: [String] -> String
html xs = ochtml "html" (U.reduceToString xs)

-- |Takes a list of strings and wraps it in a head-tag
hHead :: [String] -> String 
hHead xs = ochtml "head" (U.reduceToString xs)

-- |Takes a list of strings and wraps it in a style-tag
style :: [String] -> String
style xs = ochtml "style" (U.reduceToString xs)

-- |Takes a string "rel" and a string "href" and creates a link-element
link :: String -> String -> String
link rel href = ohtml ("link " ++ aRel rel ++ aHref href)

-- |Recursive Function that takes a list of String and puts them together.
-- |wraps the finished String with a body-element
body :: [String] -> String
body xs = ochtml "body" (U.reduceToString xs)

-- |Recursive Function that takes a String (Link / Path) and a list of Strings. The link-String gets
-- |wrapped in the open-html-tags and the rest gets wrapped by a-tags
a :: String -> [String] -> String
a l = r_a (ohtml ("a " ++ aHref l))
   where r_a acc []     = acc ++ chtml "a"
         r_a acc (x:xs) = r_a (acc ++ x) xs

-- |Takes a list of strings and puts them in between h1-tags
h1 :: [String] -> String
h1 xs = ochtml "h1" (U.reduceToString xs)


-- List-Elements --

-- |Takes a list of strings and puts them in between li-tags (elements of a list)
li :: [String] -> String
li xs = ochtml "li" (U.reduceToString xs)

-- |Takes a list of strings and creates a list. li-tags should not be set 
-- |in the string-array
ul :: [String] -> String
ul = r_ul (ohtml "ul")
   where r_ul acc []     = acc ++ chtml "ul"
         r_ul acc (x:xs) = r_ul (acc ++ li [x]) xs

-- |Creates a list in which all list-elements are a link their name.
ll :: [String] -> String
ll = r_ll (ohtml "ul")
      where r_ll acc []     = acc ++ chtml "ul"
            r_ll acc (x:xs) = r_ll (acc ++ li [a ("authors/" ++ x) [x]]) xs


-- Table-Elements --

-- |Takes a list of strings and wraps them in table-tags
table :: [String] -> String
table xs = ochtml "table" (U.reduceToString xs)

-- |Takes a string and wraps it with th-tags
th :: String -> String
th = ochtml "th"

-- |Takes a string and wraps it with td-tags
td :: String -> String
td = ochtml "td"

-- |Takes a bgcolor String and a style String and returns a td-element with those values as attributes
atd :: String -> String -> String
atd c s = ohtml ("td " ++ aBgcolor c ++ " " ++ aStyle s) ++ chtml "td"

-- |Takes a list of strings and wraps it with a tr-tag
tr :: [String] -> String
tr xs = ochtml "tr" (U.reduceToString xs)

-- |Simple html-break with just opening-html-tags
br :: String
br = ohtml "br"

-- |Takes a list of strings (without td/th-tags) and creates a header element for a table
tHead :: [String] -> String
tHead = r_tHead (ohtml "tr")
      where r_tHead acc []     = acc ++ chtml "tr"
            r_tHead acc (x:xs) = r_tHead (acc ++ th x) xs


-- Form-Elements

-- |Takes a tuple (action, method) and list of strings [labels or inputs] and 
-- |creates a html-form with either a post or get method and a correlated link
form :: (String, String) -> [String] -> String
form (ac, me) = r_form (ohtml ("form " ++ aAction ac ++ " " ++ aMethod me))
      where r_form acc []     = acc ++ chtml "form"
            r_form acc (x:xs) = r_form (acc ++ x) xs

-- |Takes a string "name" and a list of String and creates a html-label for a form
label :: String -> [String] -> String
label s = r_label (ohtml ("label " ++ aFor s))
      where r_label acc [] = acc ++ chtml "label" 
            r_label acc (x:xs) = r_label (acc ++ x) xs

-- |Takes a triple (type, id, name) and creates a html-input field with those values
input :: (String, String, String) -> String
input (t, i, name) = 
      ohtml ("input " ++ 
             aType t ++ " " ++
             aId i ++ " " ++
             aName name)

