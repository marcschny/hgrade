{-|
    This module creates a form that takes an author-name, a grader-name and multiple grading-categories (dynamically) and returns a html-form.
-}

module Hgrade.GradingForm where

    
import           Web.Scotty (html, ActionM)
import           Data.Char (toLower)
import qualified Data.Text.Lazy      as T

import qualified Hgrade.HtmlElements as E
import qualified Hgrade.Constants    as C
import qualified Hgrade.Utils        as U

-- |Creates an ActionM () that returns a html-form with author-name, grader-name and as many grading-categories as there are in C.headCategories
gradeHtml :: ActionM ()
gradeHtml = 
    html (T.pack (E.body [
        E.h1 ["Grade"],
        E.form ("/grade", "post") [
            E.label "author" ["Author:"],
            E.input ("text", "author", "author"),
            E.br,
            E.label "Grader" ["Grader:"],
            E.input ("text", "grader", "grader"),
            E.br,
            U.reduceToString (map (\x -> E.label x [x, ":"] ++
                    E.input ("text", x, x) ++ E.br) C.headCategories),
            E.input ("submit", "Send", "")
        ]
    ]))

-- |Takes a String and returns the same string with a lowercase-head. Used to turn C.headCategories into categories with a lowercase letter at the front.
lowHead :: String -> String
lowHead s = toLower (head s) : tail s 