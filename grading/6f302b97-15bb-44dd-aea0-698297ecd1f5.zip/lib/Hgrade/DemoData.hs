{-|
    This module creates dummy/demo - data for authors and graders. The author-function can be expanded by adding an additional number and a list, where
    the first argument is the head is the author name and the tail are grader.txt's. With this data, the module creates folders for authors and
    .txt-files for graders in the data/-folder. The values in the .txt-files are random between 0 and 2
-}

module Hgrade.DemoData where

import           Control.Monad.IO.Class (liftIO)
import           System.Random ( randomRIO )
import           System.Directory ( createDirectory, createDirectoryIfMissing )

import qualified Hgrade.Constants as C
import qualified Hgrade.Utils     as U

-- |Creates an IO () action that (if missing) creates the data/-folder and then fills it with author-folders and grader-txt's. 
demoData :: IO ()
demoData = do
    createDirectoryIfMissing False C.dataLoc

    mapM_ (\x -> createDirectory (C.dataLoc ++ head x)) (allAuthors 4)
    mapM_ (\graders -> mapM (\x -> writeTxtFile (createPath (head graders) x)) (tail graders)) (allAuthors 4)

-- |Takes an Int (represents the number of authors added in the author-function) and returns an array of string-arrays from the author-function.
allAuthors :: Int -> [[String]]
allAuthors = r_af []
    where r_af acc 0 = acc
          r_af acc i = r_af (acc ++ [author i]) (i - 1)

-- |Takes a String (path) and creates a .txt-file at the given location. Fills this file with random integers of (length C.headCategories) to keep it dynamic
writeTxtFile :: String -> IO ()
writeTxtFile s = do
    input <- mapM liftIO (randomIntArray (length C.headCategories))
    writeFile s (U.intArrayToString input)

-- |Takes two Strings (author and grader) and returns a string that leads to a grader.txt-file
createPath :: String -> String -> String
createPath a g = C.dataLoc ++ a ++ "/" ++ g ++ ".txt"

-- |Takes an Int (Count) and creates an IO-Int Array [IO-Int] that is filled with as many random Ints as there is count 
randomIntArray :: Int -> [IO Int]
randomIntArray i = do replicate i (randomRIO(0, 2) :: IO Int)

-- |Takes an int and returns the corresponding array, where the head is the author-name and the head are graders
author :: Int -> [String]
author 1 = ["author1", "grader1", "grader2"]
author 2 = ["author2", "grader1", "grader2", "grader3"]
author 3 = ["author3", "grader1"]
author 4 = ["author4", "grader1", "grader2", "grader3", "grader4"]
author _ = []
