{-|
    This module contains simple functions that can be used by multiple Modules. Therefore, it is its 
    own module and can be imported by modules that need those function.
-}

module Hgrade.Utils where

import           Web.Scotty ( Param )
import           Data.Char (isDigit, digitToInt)
import qualified Data.Text.Lazy as T

-- |Takes a list of param [Param] and returns the same list but only the values of these params.
paramsToList :: [Param] -> [T.Text]
paramsToList = map getValue 

-- |Get the key / first element of a tuple
getKey :: (a, b) -> a
getKey (k,_) = k

-- |Get the value / second element of a tuple
getValue :: (a, b) -> b
getValue (_, v) = v

-- |Takes a list of strings [String] and returns a String that is a concatination of all the strings in the array
reduceToString :: [String] -> String
reduceToString = r_rs ""
    where r_rs acc []     = acc
          r_rs acc (x:xs) = r_rs (acc ++ x) xs

-- |Transposes an array of arrays [[a]], so that all columns become rows and vice-verca
colsToRows :: [[a]] -> [[a]]
colsToRows [[]] = []
colsToRows ([]:_) = []
colsToRows list = map head list : colsToRows (map tail list)

-- |Returns the sum of all elements of a triple (Int, Int, Int)
tripleSum :: (Int, Int, Int) -> Int
tripleSum (x, y, z) = x + y + z

-- |Takes an int-array [Int] and returns the stringified version of this array
intArrayToString :: [Int] -> String
intArrayToString = r_conv "["
    where r_conv acc []     = acc ++ "]"
          r_conv acc [x]    = r_conv (acc ++ show x) []
          r_conv acc (x:xs) = r_conv (acc ++ show x ++ ",") xs

-- |Takes a string of this layout = "[1, 2, 2, 0, 1]" and returns it of an int-array [1, 2, 2, 0, 1]
stringToIntArray :: [Char] -> [Int]
stringToIntArray s = map digitToInt (filter isDigit s)

-- |Takes a list of strings ["[1, 2, 2, 0, 1]", "[0, 0, 1, 2, 0]"] and returns a list of list of Ints with the same layout [[1, 2, 2, 0, 1], [0, 0, 1, 2, 0]]
stringsToIntArrays :: [String] -> [[Int]]
stringsToIntArrays = map stringToIntArray

-- |Takes an array of Text [Text] and returns a String-representation of the Text.
createFileFormat :: [T.Text] -> String
createFileFormat = r_cff "["
    where r_cff acc []     = acc ++ "]"
          r_cff acc [x]    = r_cff (acc ++ T.unpack x) []
          r_cff acc (x:xs) = r_cff (acc ++ T.unpack x ++ ",") xs