{-|
Module      : Main (Unit Tests)
Description : Module containing various unit tests.
-}
module Main (main) where

import Hgrade.Html (h1, a, tag, fullHtml)
import Hgrade.Helpers (stitch, cols2Rows, median, genHistogram, countPoints)
import Test.Tasty
import Test.Tasty.HUnit


-- |Main method.
main :: IO ()
main = defaultMain tests

-- |Main test entry point.
tests :: TestTree
tests = testGroup "Tests" [unitTests]


-- |Function containing all the unit tests.
unitTests :: TestTree
unitTests = testGroup "Unit tests"
  [ 
    ---------------------
    -- Stitching tests --
    ---------------------
    testCase "Stitch empty list" $
      stitch [] @?= "",

    testCase "Stitch singleton list" $
      stitch ["hello"] @?= "hello",

    testCase "Stitch two words" $
      stitch ["hello","world"] @?= "helloworld",

    testCase "Stitch larger list" $
      stitch ["hello","world", "!"] @?= "helloworld!",

    
    ----------------
    -- HTML tests --
    ----------------
    testCase "Wrap with h1 and a" $
      h1 [a "/target1" "Your Target"] @?= "<h1><a href=\"/target1\">Your Target</a>\n</h1>\n",


    -- Test case for generating an html containing a full html-page, including:
    -- - Full html-header
    -- - importing the css-file
    -- - Full html-body including an h1 and a p tag
    testCase "Full html test" $
      fullHtml [tag "h1" ["Welcome"], tag "p" ["nice"]] @?= "<!doctype html>\n<html lang=\"en\">\n<head><link rel=\"stylesheet\" href=\"/static/styles.css\"></head>\n<body><h1>Welcome</h1>\n<p>nice</p>\n</body>\n</html>\n",


    ---------------------
    -- cols2Rows tests --
    ---------------------
    testCase "ColsToRows 1: on [[\"\"]]" $
      cols2Rows [[""]] @=? [[""]],

    testCase "ColsToRows 2: on [[\"1\"],[\"2\"]]" $
      cols2Rows [["1"],["2"]] @=? [["1","2"]],

    testCase "ColsToRows 3: 5 values" $
      cols2Rows [["author11","author22","author33","author44","author55"],["val1","val2","val3","val4","val5"]]  
      @?= [["author11","val1"],["author22","val2"],["author33","val3"],["author44","val4"],["author55","val5"]],

    testCase "ColsToRows 4: 9 values" $
      cols2Rows [["1", "2", "3"],["4", "5", "6"],["7", "8", "9"]] @=? [["1","4","7"],["2","5","8"],["3","6","9"]],

    ------------------
    -- Median tests --
    ------------------
    testCase "Median of [] should be 0.0" $
      median [] @?= 0,

    testCase "Median of [2] should be 2.0" $
      median [2] @?= 2.0,

    testCase "Median of [1, 3, 3, 6, 7, 8, 9] should be 6" $
      median [1, 3, 3, 6, 7, 8, 9] @?= 6,

    testCase "Median of [2, 1, 1, 2] should be 1.5" $
      median [2, 1, 1, 2] @?= 1.5,

    testCase "Median of [1, 2, 3, 4, 5, 6, 8, 9] should be 4.5" $
      median [1, 2, 3, 4, 5, 6, 8, 9] @?= 4.5,

    ---------------------
    -- Histogram tests --
    ---------------------
    testCase "CountPoints for []" $
      countPoints [] @?= [0,0,0],

    testCase "genHistogram for [] (countPoints would be [0,0,0])" $
      genHistogram [] (maximum (countPoints [])) "black" "white" @?= [["white","white","white"]],


    testCase "CountPoints for [1]" $
      countPoints [1] @?= [0,1,0],

    testCase "genHistogram for [1] (countPoints would be [0,1,0])" $
      genHistogram [1] (maximum (countPoints [1])) "black" "white" @?= [["white","white","white"],["white","black","white"]],


    testCase "CountPoints for [0,2,2,0]" $
      countPoints [0,2,2,0] @?= [2,0,2],

    testCase "genHistogram for [0,2,2,0] (countPoints would be [2,0,2])" $
      genHistogram [0,2,2,0] (maximum (countPoints [0,2,2,0])) "black" "white" @?= [["white","white","white"],["black","white","black"],["black","white","black"]],


    testCase "CountPoints for [1,1,1,2]" $
      countPoints [1,1,1,2] @?= [0,3,1],

    testCase "genHistogram for [1,1,1,2] (countPoints would be [1,1,1,2])" $
      genHistogram [1,1,1,2] (maximum (countPoints [1,1,1,2])) "black" "white" @?= [["white","white","white"],["white","black","white"],["white","black","white"],["white","black","black"]]



    -- Don't forget to add a comma to the previous test-case when adding new test-cases!!!


  ]

