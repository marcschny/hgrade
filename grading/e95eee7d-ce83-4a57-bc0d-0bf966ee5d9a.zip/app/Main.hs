{-|
Module      : Main
Description : Module with the main entry point for the application.
-}
module Main where

import qualified Hgrade

main :: IO ()
main = Hgrade.main