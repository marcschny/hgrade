{-|
Module      : Hgrade.ReadWrite
Description : Module containing functions for reading and writing from/to the disk.
-}
module Hgrade.ReadWrite where

import System.Directory ( createDirectoryIfMissing, listDirectory, withCurrentDirectory )


-- |Creates or overwrites a file, and creates parent directories if not yet present.
--
-- * 1st param: File path (without the filename, ending with /)
-- * 2nd param: File name
-- * 3rd param: Content to write to the file
overwriteFile :: FilePath -> String -> String -> IO ()
overwriteFile filePath fileName content = do 
    createDirectoryIfMissing True filePath
    writeFile (filePath ++ fileName) content


-- |Reads one file, writes the content to the console and returns the IO String
-- 
-- * 1st param: Full file path (including the filename)
-- * Returns the IO String with the content
readOneFile :: String -> IO String
readOneFile fullFilePath = do 
    content <- readFile fullFilePath
    putStr content
    return content


-- |Reads all files in a given file path and returns their contents
--
-- Version with lambda for better understandability of this function:
--
-- @     mapM (\x -> withCurrentDirectory filePath (readFile x)) fileList @
--
-- * 1st param: filePath for the directory of the files
-- * Returns a list of IO Strings containing the content of each file
readAllFiles :: String -> IO [String]
readAllFiles filePath = do
    fileList <- listDirectory filePath
    mapM (withCurrentDirectory filePath . readFile) fileList


