{-|
Module      : Hgrade.Html
Description : Module for various functions for creating html and html-tags.
-}
module Hgrade.Html where

import Hgrade.Helpers ( stitch, stitchSpace )
import Data.List ( sort )


-- |Simple tag
--
-- * 1st param: the tag
-- * Returns a string with the surrounding brackets
simpleTag :: String -> String
simpleTag t = "<" ++ t ++ ">"


-- |End tag (including newline)
endTag :: String -> String
endTag t = simpleTag ("/" ++ t) ++ "\n"


-- |Surround by a tag
--
-- * 1st param: Name of the tag
-- * 2nd param: Content (a list of Strings)
-- * Returns a String
tag :: String -> [String] -> String
tag t s = stitch [simpleTag t, stitch s, endTag t] 


-- |Simple tag with attributes, e.g. @<link rel="stylesheet" href="stylesheet.css">@
--
-- * 1st param: Name of the tag
-- * 2nd param: Attributes (a list of String)
-- * Returns a String
simpleTagWithAttr :: String -> [String] -> String
simpleTagWithAttr t attributes = stitch [simpleTag (t ++ " " ++ stitchSpace attributes)] 


-- |Tag with attributes
--
-- * 1st param: Name of the tag
-- * 2nd param: Attributes (a list of String)
-- * 3rd param: Content (a list of Strings)
-- * Returns a String
tagWithAttr :: String -> [String] -> [String] -> String
tagWithAttr t attributes s = stitch [simpleTagWithAttr t attributes, stitch s, endTag t] 


-- |Attribute for inside a tag
--
-- * 1st param: Parameter
-- * 2nd param: Value
-- * Returns a String
attr :: String -> String -> String
attr param1 value1 = stitch [param1, "=\"", value1, "\""]

---------------------------------------------
-- SECTION WITH VARIOUS CONCRETE HTML-TAGS --
---------------------------------------------

-- |Tag head  (note: 'head' had an ambiguous occurrence, hence I had to rename this to headTag)
--
-- (hint: with ETA-reduction, you can reduce @head s = tag "head" s@ to @head = tag "head"@)
headTag :: [String] -> String
headTag = tag "head"


-- |Tag body
body :: [String] -> String
body = tag "body"


-- |Tag h1
h1 :: [String] -> String
h1 = tag "h1"


-- |Tag div
divTag :: [String] -> String
divTag = tag "div"


-- |Tag p
p :: [String] -> String
p = tag "p"


-- |Tag li (one entry for a list)
li :: [String] -> String
li = tag "li"


-- |Tag ul (unordered list)
ul :: [String] -> String
ul = tag "ul"

-- |Tag br
br :: String
br = simpleTag "br"


-- |Tag a (link)
--
-- Example: @a "/data" "Goal"@ -> would result in @<a href="/data">Goal</a>@
--
-- * 1st param: Link (to navigate to)
-- * 2nd param: Name (to show)
-- * Returns a String
a :: String -> String -> String
-- a link name = stitch ["<a href=", link, ">", name, "</a>"]
a link name = tagWithAttr "a" [attr "href" link] [name]


-- |Tag table
table :: [String] -> String
table = tag "table"


-- |Tag tr
tr :: [String] -> String
tr = tag "tr"


-- |Tag th
th :: [String] -> String
th = tag "th"


-- |Tag td
td :: [String] -> String
td = tag "td"



---------------
-- Form tags --
---------------
-- |Tag form (sending a form, automatically adding the attribute method="post")
--
-- Complete html for form:
-- 
-- 
-- <form action='/name' method='post'>
--   <label for='Name_ID'>Name:</label>
--   <input type='text' id='Name_ID' name='Name'></input>
--   <input type='submit' value='Send'></input>
-- </form>
-- 
--
-- Example: @ <form action='/name' method='post'> @
--
-- * 1st param: action, e.g. "/graded"
-- * 2nd param: content (label, input, ...)
-- * Returns a String
form :: String -> [String] -> String
form action = tagWithAttr "form" [attr "action" action, attr "method" "post"]


-- |Tag label (for a form)
--
-- Example: @ <label for='Name_ID'>Name:</label> @
--
-- * 1st param: for, e.g. "Name_ID"
-- * 2nd param: text string
-- * Returns a String
label :: String -> String -> String
label for textStr = tagWithAttr "label" [attr "for" for] [textStr]


-- |Input label (for a form)
--
-- Examples:
-- 
-- * @ <input type='text' id='Name_ID' name='Name'></input> @
-- * @ <input type='submit' value='Send'></input> @
--
-- * 1st param: attributes (with function 'attr')
-- * Returns a String
inputTag :: [String] -> String
inputTag attributes = tagWithAttr "input" attributes [""]


-- |Specialization for text input
--
-- Example: @ <input type='text' id='Name_ID' name='Name'></input> @
--
-- * 1st param: attribute id
-- * 2nd param: attribute name
-- * Returns a String
textInput :: String -> String -> String
textInput idAttr nameAttr = inputTag [attr "type" "text", attr "id" idAttr, attr "name" nameAttr]


-- |Creates a complete row for a text input in a form
--
-- * 1st param: attribute name
-- * Returns a String
formRow :: String -> String
formRow name =
        label (name ++ "_ID") (name ++ ":") ++
        textInput (name ++ "_ID") name ++ br ++ "\n"


-- |Specialization for submit input
--
-- Example: @ <input type='submit' value='Send'></input> @
--
-- * Returns a String
submitInput :: String
submitInput = inputTag [attr "type" "submit", attr "value" "Send"]


----------------------------
-- Various html functions --
----------------------------

-- |White box for the histogram
whiteBox :: String
whiteBox = tagWithAttr "td" [attr "class" "white box"] [""] 


-- |Black box for the histogram
blackBox :: String
blackBox = tagWithAttr "td" [attr "class" "black box"] [""] 


-- |Create list of authors
-- 
-- With function composition inside the map, I could compress it to one statement, so that both operations are applied at the same time.
--
-- * 1st param: list with autors
listAuthors :: [String] -> String
listAuthors listA = ul (map (li . authorLink) (sort listA))


-- |Creates the link-string for an author.
authorLink :: String -> [String]
authorLink author = [a ("/authors/" ++ author) author]


-- |Construct full html-template, including body. Example usage:
--
-- @   fullHtml [tag "h1" ["Welcome"], tag "p" ["nice"]]@
--
-- This would return:
--
-- @   "<!doctype html>\n<html lang=\"en\">\n<head></head>\n<body>\n<h1>Welcome</h1>\n<p>nice</p>\n</body>\n</html>"@
--
-- Old version:
-- @   fullHtml s = stitch ["<!doctype html>\n<html lang=\"en\">\n<head></head>\n<body>\n", stitch s, "</body>\n</html>"] @
-- 
-- * 1st param: Content (as List of Strings)
-- * Returns the full html code for rendering a page, as a String
fullHtml :: [String] -> String
fullHtml content = stitch [
    simpleTag "!doctype html", "\n",
    tagWithAttr "html" [attr "lang" "en"] [
        "\n",
        headTag [
            simpleTagWithAttr "link" [attr "rel" "stylesheet", attr "href" "/static/styles.css"]
        ],
        body content
    ]]


