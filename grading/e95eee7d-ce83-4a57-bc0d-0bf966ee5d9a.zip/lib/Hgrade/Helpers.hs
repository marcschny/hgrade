{-|
Module      : Hgrade.Helpers
Description : Module for various helper functions.
-}
module Hgrade.Helpers where

import Data.List ( sort )

-- |Stitch strings from a list together
stitch :: [String] -> String
stitch [] = ""
stitch [s] = s
stitch (s:s':ss) = s ++ stitch (s':ss)  


-- |Stitch strings from a list together, with a space in between the strings
stitchSpace :: [String] -> String
stitchSpace [] = ""
stitchSpace [s] = s
stitchSpace (s:s':ss) = s ++ " " ++ stitch (s':ss)  


-- |Transpose colums to rows
cols2Rows :: [[t]]->[[t]]
cols2Rows [] = []
cols2Rows ([]:x) = cols2Rows x
cols2Rows x = map head x : cols2Rows (map tail x)


-- |Method for calculating the median
median :: [Int] -> Float
median nums = medianUnsorted (sort nums)


-- |Calculates the medianUnsorted from a list of Int
medianUnsorted :: [Int] -> Float
medianUnsorted nums 
    | null nums = 0.0
    | odd len = fromIntegral (nums !! middle)
    | even len = medEven
    | otherwise = 0.0
        where   len = length nums
                middle = div len 2
                medEven = fromIntegral (nums !! (middle - 1) + nums !! middle) / 2



-- |Finds the maximum value in a matrix of integers
findMaxInMatrix :: [[Int]] -> Int
findMaxInMatrix nums = maximum (map maximum nums)


-------------------
-- For histogram --
-------------------

-- |Generates a histogram - as a list of list of strings
--
-- Example for explanation (see also unit test case "genHistogram1"):
-- 
-- * Given @n1 = [0,2,2,0]
-- * @ genHistogram n1 (maximum (countPoints n1)) "black" "white" @
-- * then the result would be:
-- * @ [["white","white","white"],["black","white","black"],["black","white","black"]] @
-- * Of course, "white" would instead be a full tag like @<td class="white box"></td>@
-- * With this, you can easily apply the tag 'tr' to each row, and voila, you have the histogram!
--
-- Parameters:
--
-- * 1st param: [Int]   The points for the histogram
-- * 2nd param: Int     Maximum point number (sets the height of the histograms)
-- * 3rd param: String  HTML-string for a black box
-- * 4th param: String  HTML-string for a white box
-- * Returns the histogram as a list of list of strings
genHistogram :: [Int] -> Int -> String -> String -> [[String]]
genHistogram points maxN black white = transposeHistogram (map (\x -> genElementsForHistogram x (1 + maxN) black white) (countPoints points))


-- |Generates one column for the histogram (currently a row, but this will turn into a column with application of 'transposeHistogram')
--
-- * 1st param: Int     The points to draw the histogram column
-- * 2nd param: Int     Maximum point number (sets the height of the histograms)
-- * 3rd param: String  HTML-string for a black box
-- * 4th param: String  HTML-string for a white box
-- * Returns the column as a string (still a row right now, but with 'transposeHistogram', this will turn into a column)
genElementsForHistogram :: Int -> Int -> String -> String -> [String]
genElementsForHistogram i maxN black white = replicate i black ++ replicate (maxN - i) white


-- |Transposed the histogram
transposeHistogram :: [[String]] -> [[String]]
transposeHistogram str = reverse (cols2Rows str)

-- |Counts elements
--
-- * 1st param: element to be counted
-- * 2nd param: list of elements to search in
count :: Eq a => a -> [a] -> Int
count x = length . filter (==x)

-- |Counts the points for the histogram
--
-- * 1st param: List of integers
countPoints :: [Int] -> [Int]
countPoints nums = [count 0 nums, count 1 nums, count 2 nums]

-- |Cuts file-ending '.txt', for showing the graders name
--
-- * It goes char by char and takes it while the condition is met
-- * Note: @/=@ is 'not equal'   (whereas @==@ is 'equal', like in other programming languages )
cutTxt :: String -> String
cutTxt = takeWhile (/= '.')



