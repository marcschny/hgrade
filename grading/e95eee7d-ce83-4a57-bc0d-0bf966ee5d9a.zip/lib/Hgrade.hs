{-# LANGUAGE OverloadedStrings #-}

{-|
Module      : Hgrade
Description : Module with the main web-application, including some main function for the web-pages.
-}
module Hgrade where

import           Web.Scotty
import           Network.Wai.Middleware.RequestLogger ( logStdoutDev )
import           System.Directory ( listDirectory )
import           Control.Monad.IO.Class ( liftIO )
import qualified Data.Text.Lazy as T
import           Data.List ( intercalate )
import           Hgrade.Html ( h1, p, li, ul, a, fullHtml, form, submitInput, formRow, listAuthors )
import           Hgrade.AuthorDetails ( details )
import           Hgrade.ReadWrite (readAllFiles, overwriteFile)


-- |Main method creating the web-server with scotty on http://localhost:4000/
main :: IO ()
main = do
  scotty 4000 $ do
    -- Middleware for logging
    middleware logStdoutDev
    
    -- Serving the base page
    get "/" indexHtml

    -- Including the CSS stylesheet
    get "/static/styles.css" $ file "static/styles.css"

    -- Showing the author overview page
    get "/authors" $ do
      files1 <- liftIO (listDirectory "data")
      allAuthorsHtml files1      

    -- Showing the authors details pages
    get "/authors/:authorname" $ do
      authorName <- param "authorname"
      graderNames <- liftIO (listDirectory ("data/" ++ authorName))
      contents <- liftIO (readAllFiles ("data/" ++ authorName))
      authorHtml authorName graderNames contents

    -- Creates the grading form
    get "/grade" gradingHtml

    -- handles sent forms for gradings
    post "/grade" gradedHtml


-- |Creates the landing page.
indexHtml :: ActionM () 
indexHtml = html (T.pack (
  fullHtml [
    h1 ["Hgrade - Peergrading in Haskell"],
    p [
      ul [
        li [a "/authors" "Grading Overview"],
        li [a "/grade" "Submit Grading"]
      ]
    ]
  ]))


-- |Creates the overview page of all the authors.
--
-- * 1st param: list of file paths
allAuthorsHtml :: [FilePath] -> ActionM ()
allAuthorsHtml files1 = html (T.pack (
  fullHtml [
    h1 ["Authors"],
    p [listAuthors files1],
    p [a "/" "back"]
    ]))


-- |Creates the analyze screen for each author.
--
-- * 1st param: author name
-- * 2nd param: list of grader names
-- * 3rd param: full contents
authorHtml :: String -> [String] -> [String] -> ActionM ()
authorHtml authorName graderNames contents = html (T.pack (
  fullHtml [
    h1 ["Author: " ++ authorName],
    p [details graderNames contents],
    p [a "/authors" "back"]
  ]))


-- |Creates the grading form.
gradingHtml :: ActionM ()
gradingHtml = html (T.pack (
  fullHtml [
    h1 ["Grade"],
    form "/grade" [
      formRow "Author",
      formRow "Grader",
      formRow "N1",
      formRow "N2",
      formRow "F1",
      formRow "F2",
      formRow "F3",
      p [submitInput],
      p [a "/" "back"]
    ]
    ]))


-- |Creates the post-form for gradings.
gradedHtml :: ActionM ()
gradedHtml = do
      author <- param "Author"
      grader <- param "Grader"
      n1 <- param "N1"
      n2 <- param "N2"
      f1 <- param "F1"
      f2 <- param "F2"
      f3 <- param "F3"
      -- IO Actions müssen mit liftIO zu einer ActionM 'angehoben' werden
      liftIO (overwriteFile ("data/" ++ author ++ "/") (grader ++ ".txt") 
        ("[" ++ intercalate "," [n1, n2, f1, f2, f3] ++ "]"))
      html (T.pack (fullHtml [
        p ["Wrote gradings to data/" ++ author ++ "/" ++ grader ++ ".txt"],
        p ["See gradings for ", a ("/authors/" ++ author) author],
        p [a "/" "back"]
        ]))

