module Main (main) where

import Test.Tasty
import Test.Tasty.HUnit

import Hgrade.GradeHandler

main :: IO ()
main = defaultMain tests

tests :: TestTree
tests = testGroup "Tests" [unitTests]

unitTests :: TestTree
unitTests = testGroup "Unit tests"
  [ 
    testCase "calculcate median on an even list" $
      median [0, 1] @?= 0.5,
    testCase "calculate median on an odd list" $
      median [0, 2, 1] @?= 1,

    testCase "histogram out of [0, 1, 1]" $
      histogram [0, 1, 1] @?= (1, 2, 0),
    testCase "histogram out of [2, 1, 2]" $
      histogram [2, 1, 2] @?= (0, 1, 2),

    testCase "colsToRows on an empty list" $
      colsToRows [] @?= [],
    testCase "colsToRows on a normal list" $
      colsToRows [[1, 2, 3], [4, 5, 6]] @?= [[1,4],[2,5],[3,6]]
  ]