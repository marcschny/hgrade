{-# LANGUAGE OverloadedStrings #-}

-- HtmlGenerator - this module is used for generating and handling html data

module Hgrade.HtmlGenerator where

-- htmlOpeningTag - wrapper for a opening html tag
htmlOpeningTag :: String -> String
htmlOpeningTag tag = "<" ++ tag ++ ">"

-- htmlClosingTag - wrapper for a closing html tag 
htmlClosingTag :: String -> String
htmlClosingTag tag = "</" ++ tag ++ ">"

-- htmlTag - concat opening and closing tags plus content to a single html tag
htmlTag :: String -> String -> String
htmlTag tag content = htmlOpeningTag tag ++ content ++ htmlClosingTag tag

-- htmlTagWithAttribs - set up a variant of htmlTag to be used with html attributes
htmlTagWithAttribs :: String -> String -> String -> String
htmlTagWithAttribs tag attribs content = "<" ++ tag ++ " " ++ attribs ++ " >" ++ content ++ htmlClosingTag tag

-- htmlTagSingle - set up a variant of htmlTag to be used for DOCTYPE
htmlTagSingle :: String -> String
htmlTagSingle tag = "<!" ++ tag ++ ">"

-- concatLines - concat a list of Strings to a single String
concatLines :: [String] -> String
concatLines [] = ""
concatLines [s] = s
concatLines (s:s':ss) = s  ++ "\n" ++ concatLines (s':ss)

-- doctype - wrapper for doctype html tag
doctype :: String
doctype = htmlTagSingle "DOCTYPE html"

-- html - wrapper for html tag
html :: [String] -> String
html content = htmlTagWithAttribs "html" "lang='en'" (concatLines content)

-- head - wrapper for head tag
head :: String -> String
head = htmlTag "head"

-- title - wrapper for title tag
title :: String -> String
title = htmlTag "title"

-- link - wrapper for link tag
link :: String -> String
link linkedRessource = htmlTagWithAttribs "link" ("rel='stylesheet' href='"++linkedRessource++"'") ""

-- body - wrapper for body tag
body :: [String] -> String
body content = htmlTag "body" (concatLines content)

-- h1 - wrapper for h1 tag
h1 :: String -> String
h1 = htmlTag "h1"

-- ul - wrapper for ul tag
ul :: [String] -> String
ul content = htmlTag "ul" (concatLines content)

-- li - wrapper for li tag
li :: String -> String
li = htmlTag "li"

-- a - wrapper for a tag
a :: (String, String) -> String
a (t, l) = htmlTagWithAttribs "a" ("href='"++l++"'") t

-- table - wrapper for table tag
table :: [String] -> String
table content = htmlTag "table" (concatLines content)

-- tr - wrapper for tr tag
tr :: [String] -> String
tr content = htmlTag "tr" (concatLines content)

-- th - wrapper for th tag
th :: String -> String
th = htmlTag "th"

-- td - wrapper for td tag
td :: String -> String
td = htmlTag "td"

-- form - wrapper for form tag
form :: String -> [String] -> String
form actionName inputFields = htmlTagWithAttribs "form" ("action='"++actionName++"' method='post'") (concatLines inputFields)

-- label - wrapper for label tag
label :: String -> String
label name = htmlTagWithAttribs "label" ("for='"++name++"_id'") name++":" 

-- inputText - wrapper for inputText tag
inputText :: String -> String
inputText name = label name ++ htmlTagWithAttribs "input" ("type='text' id='"++name++"_id' name='"++name++"'") "" ++ htmlClosingTag "br"

-- inputSubmit - wrapper for inputSubmit tag
inputSubmit :: String -> String
inputSubmit name = htmlTagWithAttribs "input" ("type='submit' value='"++name++"'") ""

-- createPage - set up the basic structure of a html page with doctype, html, head (inlcuding css) and body tags
createPage :: String -> [String] -> String
createPage titleOfPage contentOfPage = concatLines [
    doctype,
    html [
      Hgrade.HtmlGenerator.head $ title titleOfPage ++ link "/static/styles.css",
      body contentOfPage
    ]
  ]