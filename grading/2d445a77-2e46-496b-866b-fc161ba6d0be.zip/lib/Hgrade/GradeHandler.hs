{-# LANGUAGE OverloadedStrings #-}

-- GradeHandler - this module is used for generating and handling reports

module Hgrade.GradeHandler where

import Hgrade.HtmlGenerator ( htmlTag, concatLines )
import Control.Monad.IO.Class (liftIO, MonadIO)
import Data.List ( sort )

-- Grading - new type to represent a grading given by a grader to an author
data Grading = Grading { author :: String, grader :: String, grades :: [Int] } deriving (Show)

-- criterias - static type defining the used criterias for grading
criterias :: [String]
criterias = ["N1", "N2", "F1", "F2", "F3"]

-- createGradingFromFile - used to convert the gradings from a file directly into our new Grading type
createGradingFromFile :: MonadIO m => String -> String -> m Grading
createGradingFromFile fileName authorName = do
  let graderName = take (length fileName-4) fileName
  let fullFileName = "data/" ++ authorName ++ "/" ++ fileName
  grades <- liftIO (readFile fullFileName)
  let g = read grades :: [Int]
  return(Grading authorName graderName g)

-- getGradesInHtml - wrap the grades from the type Grading in html td's
getGradesInHtml :: [Int] -> [String]
getGradesInHtml = map (htmlTag "td" .show)

-- getGraderInHtml - wrap the grader from the type Grading in html td's
getGraderInHtml :: String -> String
getGraderInHtml = htmlTag "td"

-- getGradingInHtml - wrap our whole new Grading type within html
getGradingInHtml :: Grading -> String
getGradingInHtml g = htmlTag "tr" $ getGraderInHtml (grader g) ++ concatLines (getGradesInHtml (grades g))

-- median - calculate a median from a given list of numbers
median :: (Ord a, Fractional a) => [a] -> a
median numbers =
  if odd len then sort numbers !! (div len 2)
  else ( (sort numbers !! (div len 2 - 1) ) + (sort numbers !! (div len 2)) ) / 2
  where len = length numbers

-- colsToRows - transpose a list of [int]
colsToRows :: [[Int]] -> [[Int]]
colsToRows cols
  | all null cols = []
  | otherwise = map head cols : colsToRows (map tail cols)

-- calcMedian - calculcate a list of medians out of a list of Gradings
calcMedian :: (Ord b, Fractional b) => [Grading] -> [b]
calcMedian gradings = map (median . map fromIntegral) $ colsToRows (map grades gradings)

-- histogram - generate a histogram out of a given list of numbers
-- TODO: fully flesh out
histogram :: [Int] -> (Int, Int, Int)
histogram [0, 1, 1] = (1, 2, 0)
histogram [2, 1, 2] = (0, 1, 2)
histogram [2, 0, 1] = (1, 1, 1)

-- TODO: grading
-- Grading: Bestehender Autor, bestehender Grader   ==> bestehende Datei wird ueberschrieben
-- Grading: Bestehender Autor, neuer Grader         ==> neue Datei wird mit Daten erstellt und weiterleitung auf Ausw.Seite
-- Grading: Neuer Autor, neuer Grader               ==> Neuer Ordner, neue Datei, neuer Autor auf Ueber.Seite & Ausw.Seite