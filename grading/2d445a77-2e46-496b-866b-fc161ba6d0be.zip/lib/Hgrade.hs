{-# LANGUAGE OverloadedStrings #-}

-- Hgrade.hs - this module handles and delivers requests

module Hgrade where

import qualified Data.Text.Lazy as T

import Web.Scotty
import Control.Monad.IO.Class (liftIO)
import Network.Wai.Middleware.RequestLogger ( logStdoutDev )
import System.Directory (listDirectory)

import Hgrade.HtmlGenerator
import Hgrade.GradeHandler

-- this is the main function were we delegate and handle our request from scotty
main :: IO ()
main = do
  scotty 4000 $ do
    middleware logStdoutDev
    
    -- startseite
    get "/" indexHtml
    
    -- übersichtsseite
    get "/authors" $ do
      directoryContents <- liftIO (listDirectory "data")
      let filteredFiles = filter (/=".DS_Store") directoryContents

      Web.Scotty.html (T.pack $ createAuthorsPage filteredFiles)

    -- auswertungsseite
    get "/authors/:authorname" $ do
      authorName <- param "authorname"

      directoryContents <- liftIO (listDirectory $ "data/" ++ authorName)
      let filteredFiles = filter (/=".DS_Store") directoryContents
      
      gradings <- mapM (`createGradingFromFile` authorName) filteredFiles

      Web.Scotty.html (T.pack $ createAuthorNamedPage authorName gradings)

    -- bewertungsseite
    get "/grade" $ do
      Web.Scotty.html (T.pack createGradePage)

    post "/grade" $ do
      author <- param "Author"
      grader <- param "Grader"
      grades <- params
      
      Web.Scotty.html (T.pack $ createPage "Submitted" [
          h1 "Submitted grading for " ++ author ++ " by " ++ grader
        ])

    get "/static/styles.css" $ file "static/styles.css"

-- indexHtml - set up html for scotty to respond to the index page
indexHtml :: ActionM () 
indexHtml = Web.Scotty.html(T.pack createIndexPage)

-- createIndexPage - create the html used for our index page
createIndexPage :: String
createIndexPage = createPage "Peergrading in Haskell" [
    h1 "Peergrading in Haskell",
    ul [
      li $ a ("Grading Overview", "/authors"),
      li $ a ("Submit Grading", "/grade")
    ]
  ]

-- createAuthorsPage - create the html used for our page listing the available authors
createAuthorsPage :: [String] -> String
createAuthorsPage authors = createPage "Authors" [
      h1 "Authors",
      ul $ map (\authorName -> li $ a (authorName, "/authors/"++authorName)) authors
  ]

-- createAuthorNamedPage - create the html for our page which shows the grades of a single author
createAuthorNamedPage :: String -> [Grading] -> String
createAuthorNamedPage authorName gradings = createPage authorName [
    h1 $ "Author: "++authorName,
    table [
      tr $ htmlTag "th" "" : map (htmlTag "th") criterias,
      concatLines $ map getGradingInHtml gradings,
      tr $ htmlTag "td" "Median" : map (htmlTag "td" .show) (calcMedian gradings)
      -- todo: histogram
    ]
  ]

-- createGradePage - create html for the form to input a new grading
createGradePage :: String
createGradePage = createPage "Grade" [
    h1 "Grade",
    form "/grade" [
      inputText "Author",
      inputText "Grader",
      concatLines $ map inputText criterias,
      inputSubmit "Send"
    ]
  ]